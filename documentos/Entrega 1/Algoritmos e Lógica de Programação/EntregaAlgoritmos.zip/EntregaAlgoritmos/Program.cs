﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int energia = 100;
        int pontos = 0;
        int faseAtual = 1;
        bool jogoAtivo = true;

        Console.WriteLine("==================================================");
        Console.WriteLine("   FUGA DO LABORATÓRIO DE INFORMÁTICA");
        Console.WriteLine("==================================================");
        Console.WriteLine("Você dormiu na faculdade e o laboratório foi trancado!");
        Console.WriteLine("Agoa, tem que passar por 3 fases para conseguir escapar.");
        Console.WriteLine("Cuidado: se a energia chegar a 0, você perde o jogo!");
        Console.WriteLine();

        Console.WriteLine("Pressione qualquer tecla para começar...");
        Console.ReadKey();
        Console.Clear();

        while (jogoAtivo && energia > 0 && faseAtual <= 3)
        {
            Console.WriteLine("==================================================");
            Console.WriteLine("Energia: " + energia + " | Pontos: " + pontos);
            Console.WriteLine("==================================================");
            Console.WriteLine();

            // ---------------- FASE 1 ----------------
            if (faseAtual == 1)
            {
                Console.WriteLine("--- FASE 1: ACESSO AO COMPUTADOR PRINCIPAL ---");
                Console.WriteLine();
                Console.WriteLine("Para desbloquear a porta do fundo, responda:");
                Console.WriteLine();
                Console.WriteLine("Em qual ano nasceu a Arcor?");
                Console.WriteLine("1) 1951");
                Console.WriteLine("2) 2000");
                Console.WriteLine("3) 2010");
                Console.WriteLine("0) Sair");
                Console.Write("Escolha uma opção: ");

                string resposta = Console.ReadLine();

                if (resposta == "0")
                {
                    Console.WriteLine("\nVocê desistiu. Fim do jogo.");
                    jogoAtivo = false;
                }
                else if (resposta == "2")
                {
                    Console.WriteLine("\nResposta correta!");
                    pontos += 50;
                    faseAtual++;

                    Console.WriteLine("Você ganhou 50 pontos!");
                    Console.WriteLine("Fase 1 concluída. Passando para a Fase 2.");
                }
                else if (resposta == "1" || resposta == "3")
                {
                    energia -= 30;

                    if (energia < 0)
                    {
                        energia = 0;
                    }

                    Console.WriteLine("\nResposta errada!");
                    Console.WriteLine("Você perdeu 30 de energia.");
                }
                else
                {
                    Console.WriteLine("\nOpção inválida!");
                    Console.WriteLine("Escolha apenas 1, 2, 3 ou 0.");
                }
            }

            else if (faseAtual == 2)
            {
                Console.WriteLine("--- FASE 2: CORREDOR DOS SERVIDORES ---");
                Console.WriteLine();
                Console.WriteLine("Você encontrou uma porta protegida por uma pergunta.");
                Console.WriteLine();
                Console.WriteLine("Em qual país a Arcor foi fundada?");
                Console.WriteLine("1) Brasil");
                Console.WriteLine("2) Estados Unidos");
                Console.WriteLine("3) Argentina");
                Console.WriteLine("0) Sair");
                Console.Write("Escolha uma opção: ");

                string resposta = Console.ReadLine();

                if (resposta == "0")
                {
                    Console.WriteLine("\nVocê desistiu. Fim do jogo.");
                    jogoAtivo = false;
                }
                else if (resposta == "3")
                {
                    Console.WriteLine("\nResposta correta!");
                    pontos += 50;
                    faseAtual++;

                    Console.WriteLine("Você ganhou 50 pontos!");
                    Console.WriteLine("Fase 2 concluída. Passando para a Fase 3.");
                }
                else if (resposta == "1" || resposta == "2")
                {
                    energia -= 30;

                    if (energia < 0)
                    {
                        energia = 0;
                    }

                    Console.WriteLine("\nResposta errada!");
                    Console.WriteLine("Você perdeu 30 de energia.");
                }
                else
                {
                    Console.WriteLine("\nOpção inválida!");
                    Console.WriteLine("Escolha apenas 1, 2, 3 ou 0.");
                }
            }

            else if (faseAtual == 3)
            {
                Console.WriteLine("--- FASE 3: A PORTA DE SAÍDA ---");
                Console.WriteLine();
                Console.WriteLine("Você chegou à última porta!");
                Console.WriteLine("Responda à última pergunta.");
                Console.WriteLine();
                Console.WriteLine("Quais desses produtos são comercializados pela Arcor no Brasil?");
                Console.WriteLine("1) Tortuguita e 7Belo");
                Console.WriteLine("2) Nutella");
                Console.WriteLine("3) Kit Kat");
                Console.WriteLine("0) Sair");
                Console.Write("Escolha uma opção: ");

                string resposta = Console.ReadLine();

                if (resposta == "0")
                {
                    Console.WriteLine("\nVocê decidiu desistir. Fim do jogo.");
                    jogoAtivo = false;
                }
                else if (resposta == "1")
                {
                    Console.WriteLine("\nResposta correta!");
                    pontos += 50;
                    faseAtual++;

                    Console.WriteLine("Você ganhou 50 pontos!");
                    Console.WriteLine("Voce concluiu todas as fases!");
                }
                else if (resposta == "2" || resposta == "3")
                {
                    energia -= 30;

                    if (energia < 0)
                    {
                        energia = 0;
                    }

                    Console.WriteLine("\nResposta errada!");
                    Console.WriteLine("Você perdeu 30 de energia.");
                }
                else
                {
                    Console.WriteLine("\nOpção inválida!");
                    Console.WriteLine("Escolha apenas 1, 2, 3 ou 0.");
                }

            }

            Console.WriteLine();

            if (jogoAtivo && energia > 0 && faseAtual <= 3)
            {
                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
                Console.Clear();
            }
        }

        Console.Clear();
        Console.WriteLine("==================================================");
        Console.WriteLine("                 FIM DO JOGO");
        Console.WriteLine("==================================================");

        if (energia <= 0)
        {
            Console.WriteLine("Você ficou sem energia e desmaiou no laboratório!");
            Console.WriteLine("GAME OVER!");
        }
        else if (faseAtual > 3)
        {
            Console.WriteLine("PARABÉNS!");
            Console.WriteLine("Você passou todas as fases e conseguiu escapar!");
            Console.WriteLine("Pontuação final: " + pontos + " pontos.");
            Console.WriteLine("Energia restante: " + energia);
        }
        else
        {
            Console.WriteLine("O jogo acabou.");
            Console.WriteLine("Pontuação final: " + pontos + " pontos.");
        }

        Console.WriteLine("==================================================");
        Console.WriteLine("Pressione qualquer tecla para fechar...");
        Console.ReadKey();
    }
}
